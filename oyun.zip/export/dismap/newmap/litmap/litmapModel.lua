
local litmapModel={}
function litmapModel:ctor()

end
return litmapModel