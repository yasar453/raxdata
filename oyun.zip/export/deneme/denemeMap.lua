local denemeMap = class("denemeMap", function()
    return display.newScene("denemeMap")
end)
function denemeMap:ctor()
    local width, height = width, height

    local mapWidth, mapHeight = 368640, 368640
    self.TILE_SIZE = 2048
    self.HALF_AREA = self.TILE_SIZE * 1.5 -- 3 tile = 3 * 2048 = 6144 / 2 = 3072
    self.EDGE_MARGIN = 100
    self.lastX=nil
    self.lastY=nil
    local layer = cc.LayerColor:create(cc.c4b(0, 0, 0, 0), mapWidth, mapHeight)
     self:addChild(layer, 1, "denemeMap")
    layer:setCameraMask(cc.CameraFlag.USER1)
    self:setName("denemeMap")
    self.gorunum = {}
    self.gorunum["layer"] = layer
    layer:setGlobalZOrder(1)
    self.layer=layer
    self.totalTile={}


    local data2 = cc.FileUtils:getInstance():getStringFromFile("deneme/loadTiles.json")
    local tiles2=json.decode(data2)
    self.tilesData={}
    local cache = cc.Director:getInstance():getTextureCache()
    for i, v in pairs(tiles2) do
           local yol=v.path
           local name=v.name
            self.tilesData[name]=yol
           local p="haritalar/terrain/"..name..".png"
            if yol=="out" then
                p=cc.FileUtils:getInstance():getWritablePath()..name..".png"
            end
          cache:addImage(p)
          local tex = cache:getTextureForKey(p)
           if tex then
                   print("✅ Texture başarıyla yüklendi!",name,p)
                else
                     print("❌ Texture yüklenemedi! Path yanlış olabilir.")
                 end
            end

    local px="haritalar/terrain/sus/".."qkar1"..".png"
    cache:addImage(px)
    for i = 1, 31 do
        local dex="qtile"..i..".png"
        local dx="haritalar/terrain/sus/"..dex
        cache:addImage(dx)
    end

    local p="haritalar/terrain/kar.png"
    local tex = cache:getTextureForKey(p)
    for i = 1, 49 do
         local sp= cc.Sprite:createWithTexture(tex)
        -- local sp= cc.Sprite:create(p)
         sp:setPosition(cc.p(0,0))
         sp:setAnchorPoint(cc.p(0.5,0.5))
         sp:setPosition3D(cc.vec3(60, 0, 90))
         sp:setCameraMask(cc.CameraFlag.USER1)
        layer:addChild(sp,1,"n"..i)
        self.totalTile["n"..i]=sp
    end
    local tex1 = cache:getTextureForKey(px)
    for i = 1, 49 do
        local sp= cc.Sprite:createWithTexture(tex1)
        --- local sp= cc.Sprite:create()
        ---sp:initWithSpriteFrameName("qtile8.png")
        sp:setPosition(cc.p(0,0))
        sp:setAnchorPoint(cc.p(0.5,0.5))
        sp:setPosition3D(cc.vec3(60, 0, 90))
        sp:setCameraMask(cc.CameraFlag.USER1)
        sp:setScale(0.5)
        layer:addChild(sp,999,"s"..i)
        self.totalTile["s"..i]=sp
    end
    local camera = cc.Camera:createOrthographic(width, height, 1, 1000)
    camera:setCameraFlag(cc.CameraFlag.USER1)
    camera:setPosition3D(cc.vec3(0, 0, 500))  -- Kamera yüksekliği
    camera:lookAt(cc.vec3(0, 0, 0), cc.vec3(0, 1, 0))
    camera:setScaleX(1)
    camera:setScaleY(2)
    camera:setPosition(cc.p(width*0.5,height*0.5))
    self:addChild(camera,999)
    self.myCamera = camera
    self:initTouchControl()
    self.map=self:initMapData()
    self.susData=self:initSusTiles()
    self.activeTiles={}
    self.activeSus={}
end
function denemeMap:iminMap(pxd)
    local function cross(v1, v2)
        return v1.x * v2.y - v1.y * v2.x
    end
    local function vector(p1, p2)
        return cc.p(p2.x - p1.x, p2.y - p1.y)
    end
    local  function isPointInsideRectangle(pt, a, b, c, d)
        local ab = vector(a, b)
        local bc = vector(b, c)
        local cd = vector(c, d)
        local da = vector(d, a)

        local ap = vector(a, pt)
        local bp = vector(b, pt)
        local cp = vector(c, pt)
        local dp = vector(d, pt)

        local cross1 = cross(ab, ap)
        local cross2 = cross(bc, bp)
        local cross3 = cross(cd, cp)
        local cross4 = cross(da, dp)

        return (cross1 >= 0 and cross2 >= 0 and cross3 >= 0 and cross4 >= 0) or
                (cross1 <= 0 and cross2 <= 0 and cross3 <= 0 and cross4 <= 0)
    end


    local p1 = cc.p(180837.00515747, 365008.6875)
    local p2 = cc.p(557.78137207031, 184235.22900391)
    local p3 = cc.p(184813.609375, 668.27575683594)
    local p4 = cc.p(365305.59375, 180480.87522888)
    local testPoint = pxd
    local ax=false
    if isPointInsideRectangle(testPoint, p1, p2, p3, p4) then
        ax=false
    else
         ax=true
    end
    return ax
end
function denemeMap:initTouchControl()
    local touchStartPos = nil
    local lastTouchPos = nil
    local velocity = cc.p(0, 0)
    local isTouching = false
    local x=90*2048
    local y=90*2048
    self.myCamera:setPosition3D(cc.vec3(x, y, 100))
    ---self.myCamera:lookAt(cc.vec3(0, 0, 0), cc.vec3(0, 1, 0))
    local friction = 1  -- Momentum azalması 0.9
    local momentumMultiplier = 4 -- Momentumun kaç katı olacak, istediğin gibi ayarla

    local function onTouchBegan(touch, event)
        isTouching = true
        touchStartPos = touch:getLocation()
        lastTouchPos = touchStartPos
        velocity = cc.p(0, 0)
        return true
    end

    local function onTouchMoved(touch, event)
        local currentPos = touch:getLocation()
        local delta = cc.pSub(currentPos, touchStartPos)

        local cam = self.myCamera
        local pos = cam:getPosition3D()

        local newX = pos.x - delta.x
        local newY = pos.y - delta.y
        local layer = self.gorunum["layer"]
        local layerSize = layer:getContentSize()
        local camWidth = display.width
        local camHeight = display.height
        local halfW = camWidth * 0.5
        local halfH = camHeight * 0.5

        -- Sınırlar
        local minX = halfW
        local maxX = layerSize.width - halfW
        local minY = halfH
        local maxY = layerSize.height - halfH

        -- Yeni pozisyon sınırları geçiyorsa, sınır değerinde kal
        newX = math.max(minX, math.min(newX, maxX))
        newY = math.max(minY, math.min(newY, maxY))
        self:isinsideSquare(newX,newY)
        local flag=self:iminMap(cc.p(newX,newY))
        if flag then
           --- cam:setPosition3D(cc.vec3(lastTouchPos.x, lastTouchPos.y, pos.z))
           ---touchStartPos = lastTouchPos
            velocity = cc.p(0, 0)
            ---lastTouchPos = lastTouchPos
        else

            cam:setPosition3D(cc.vec3(newX, newY, pos.z))
           --- cam:lookAt(cc.vec3(newX, newY, pos.z), cc.vec3(0, 1, 0))
            touchStartPos = currentPos
            velocity = cc.pSub(currentPos, lastTouchPos)
            lastTouchPos = currentPos
        end
       -- cam:setPosition3D(cc.vec3(newX, newY, pos.z))
       --- print("konum",newX, newY)

    end

    local function onTouchEnded(touch, event)
        isTouching = false
        velocity.x = velocity.x * momentumMultiplier
        velocity.y = velocity.y * momentumMultiplier
    end
    local function onTouchCancelled(touch, event)
        isTouching = false
    end

    -- Momentum için update fonksiyonu
    local function onUpdate(dt)
        if not isTouching then
            local speed = math.sqrt(velocity.x * velocity.x + velocity.y * velocity.y)

            if speed > 0.01 then
                local decay = 1 - dt * friction
                if decay < 0 then decay = 0 end

                velocity.x = velocity.x * decay
                velocity.y = velocity.y * decay

                local oldPos = self.myCamera:getPosition3D()
                local newX = oldPos.x - velocity.x
                local newY = oldPos.y - velocity.y
                local layer = self.gorunum["layer"]
                local layerSize = layer:getContentSize()
                local camWidth = display.width
                local camHeight = display.height
                local halfW = camWidth * 0.5
                local halfH = camHeight * 0.5

                local minX = halfW
                local maxX = layerSize.width - halfW
                local minY = halfH
                local maxY = layerSize.height - halfH

                if newX < minX then
                    newX = minX
                    velocity.x = 0
                elseif newX > maxX then
                    newX = maxX
                    velocity.x = 0
                end

                if newY < minY then
                    newY = minY
                    velocity.y = 0
                elseif newY > maxY then
                    newY = maxY
                    velocity.y = 0
                end
                self:isinsideSquare(newX,newY)
                local flag=self:iminMap(cc.p(newX,newY))
                if flag then print("dısardayım")
                    ---  self.myCamera:setPosition3D(cc.vec3(lastTouchPos.x, lastTouchPos.y, oldPos.z))
                else
                    print("icerdeyim")

                    self.myCamera:setPosition3D(cc.vec3(newX, newY, oldPos.z))
                   --- self.myCamera:lookAt(cc.vec3(newX, newY, oldPos.z), cc.vec3(0, 1, 0))
                end
              --  print("xd",newX, newY)

            else
                velocity = cc.p(0, 0) -- durdu
            end
        end
    end



    local listener = cc.EventListenerTouchOneByOne:create()
    listener:setSwallowTouches(true)
    listener:registerScriptHandler(onTouchBegan, cc.Handler.EVENT_TOUCH_BEGAN)
    listener:registerScriptHandler(onTouchMoved, cc.Handler.EVENT_TOUCH_MOVED)
    listener:registerScriptHandler(onTouchEnded, cc.Handler.EVENT_TOUCH_ENDED)
    listener:registerScriptHandler(onTouchCancelled, cc.Handler.EVENT_TOUCH_CANCELLED)

    local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener, self)
    self:scheduleUpdateWithPriorityLua(onUpdate, 0)
end
function denemeMap:initMapData()
    local data={}
    local data2 = cc.FileUtils:getInstance():getStringFromFile("deneme/naq.json")
    local tiles2=json.decode(data2)

    local mapTileHeight = 180
    for i, v in pairs(tiles2) do
        local res = v.r
        local x = tonumber(v.x)
        local y = tonumber(v.y)
        local correctedY = mapTileHeight - 1 - y
        local dx = x.."_"..correctedY
        local path= self.tilesData[res]
        local a={}
        a["pic"]=res
        a["path"]=path
        data[dx] = a
    end
    return data
end
function denemeMap:giveTiles(centerX,centerY)
        local tiles = {}
        for dx = -3, 3 do
            for dy = -3, 3 do
                local tileX = centerX + dx
                local tileY = centerY + dy
                table.insert(tiles, {x = tileX, y = tileY})
            end
        end
        return tiles
    end
function denemeMap:isinsideSquare(centerX,centerY)
    local minX = centerX - self.HALF_AREA
    local maxX = centerX + self.HALF_AREA
    local minY = centerY - self.HALF_AREA
    local maxY = centerY + self.HALF_AREA
    if self.lastX==nil then
        self:handleTiles(centerX,centerY)
    else
        local pointX=self.lastX
        local pointY=self.lastY
        if pointX >= minX and pointX <= maxX and pointY >= minY and pointY <= maxY then
            -- İçeride ama kenara yakın mı?
            if (pointX - minX) < self.EDGE_MARGIN or (maxX - pointX) < self.EDGE_MARGIN or
                    (pointY - minY) < self.EDGE_MARGIN or (maxY - pointY) < self.EDGE_MARGIN then
                self:handleTiles(centerX,centerY)
                return "icerde ama sinira yakin"

            else
                return "icerde"
            end
        else
            self:handleTiles(centerX,centerY)
            return "disarda"
        end
    end

end
function denemeMap:initTiles(tiles)
    local eski_kordinatlar =self.activeTiles
    local eskix={}
    local yeni_kordinatlar =tiles
    local function kordinat_key(k)
        return tostring(k.x) .. "_" .. tostring(k.y)
    end
    local yeni_map = {}
    for _, k in ipairs(yeni_kordinatlar) do
        yeni_map[kordinat_key(k)] = true
    end
    local silinecekler = {}
    for i, k in ipairs(eski_kordinatlar) do
        local key = kordinat_key(k)
        if not yeni_map[key] then
            table.insert(silinecekler, k)
        end
    end
    for i, v in pairs(silinecekler) do
        local addKor=kordinat_key(v)
        self.activeTiles[addKor]=nil
      ---  self.layer:removeChildByName(addKor)
       --- print("silinenKonum",addKor,i)
    end
    local eski_map = {}
    for _, k in ipairs(eski_kordinatlar) do
        eski_map[kordinat_key(k)] = true
    end
    for _, k in ipairs(yeni_kordinatlar) do
        local key = kordinat_key(k)
        if not eski_map[key] then
            table.insert(eskix, k)
        end
    end
    local d=0
    for _, k in ipairs(eskix) do
        if k then
            d=d+1
            local addKor=kordinat_key(k)
            self.activeTiles[addKor]=k
            ---print("addKonum",k.x, k.y)
            local x=tonumber(k.x)*2048
            local y=tonumber(k.y)*2048
            local res=self.map[addKor]
            local tileDex="n"..d
            local tile=self.totalTile[tileDex]
            if tile then
                if res then
                    local pic=res["pic"]
                    local path=res["path"]

                    local p="haritalar/terrain/"..pic..".png"
                     if path=="out" then
                         p=cc.FileUtils:getInstance():getWritablePath()..pic..".png"
                      end
                    tile:setTexture(p)
                    tile:setName(addKor)
                    tile:setPosition(cc.p(x,y))
                    print("atandx",res)
                else
                    local p="deneme/tiles/merkez.png"
                    tile:setTexture(p)
                    tile:setName(addKor)
                   -- tile:setLocalZOrder(y)
                    tile:setPosition(cc.p(x,y))

                end
            end
        end
    end

end
function denemeMap:handleTiles(centerX,centerY)
    self.lastX=centerX
    self.lastY=centerY
    local cx=math.floor(centerX/2048)
    local cy=math.floor(centerY/2048)
    local tiles=self:giveTiles(cx,cy)
    self:initTiles(tiles)
    self:putSusTiles(tiles)
end
function denemeMap:initSusTiles()
    local data={}
    local data2 = cc.FileUtils:getInstance():getStringFromFile("deneme/nsus.json")
    local tiles2=json.decode(data2)
    local mapTileHeight=180
    for i, v in pairs(tiles2) do
        local res = v.r
        local x = tonumber(v.x)
        local y = tonumber(v.y)
        local correctedY = mapTileHeight - 1 - y
        local dx = x.."_"..correctedY
        data[dx] = res
    end
    return data
end
function denemeMap:putSusTiles(tiles)

    local eski_kordinatlar =self.activeSus
    local eskix={}
    local yeni_kordinatlar =tiles
    local function kordinat_key(k)
        return tostring(k.x) .. "_" .. tostring(k.y)
    end
    local yeni_map = {}
    for _, k in ipairs(yeni_kordinatlar) do
        yeni_map[kordinat_key(k)] = true
    end
    local silinecekler = {}
    for i, k in ipairs(eski_kordinatlar) do
        local key = kordinat_key(k)
        if not yeni_map[key] then
            table.insert(silinecekler, k)
        end
    end
    for i, v in pairs(silinecekler) do
        local addKor=kordinat_key(v)
        self.activeSus[addKor]=nil
        ---  self.layer:removeChildByName(addKor)
        --- print("silinenKonum",addKor,i)
    end
    local eski_map = {}
    for _, k in ipairs(eski_kordinatlar) do
        eski_map[kordinat_key(k)] = true
    end
    for _, k in ipairs(yeni_kordinatlar) do
        local key = kordinat_key(k)
        if not eski_map[key] then
            table.insert(eskix, k)
        end
    end
    local d=0
    for _, k in ipairs(eskix) do
        if k then
            d=d+1
            local addKor=kordinat_key(k)
            self.activeSus[addKor]=k
            ---print("addKonum",k.x, k.y)
            local x=tonumber(k.x)*2048
            local y=tonumber(k.y)*2048
            local res=self.susData[addKor]
            local tileDex="s"..d
            local tile=self.totalTile[tileDex]
            if res then
                local p=res..".png"
                local px="haritalar/terrain/sus/"..p
                 tile:setTexture(px)
               --- tile:initWithSpriteFrameName(p)
                tile:setName(addKor)
                tile:setPosition(cc.p(x,y))
                print("suxx",res)
            end
        end
    end

end
local smallMap = {
    {x = 3228.6650390625,   y = 19.498245239258},
    {x = 17.468048095703,   y = 1878.7888183594},
    {x = 3074.9914550781,   y = 3272.4580078125},
    {x = 6515.3955078125,   y = 1795.4631347656},
}
local bigMap={
    {x =180837.00515747,   y = 365008.6875},
    {x =557.78137207031,   y =184235.22900391},
    {x =184813.609375,   y =668.27575683594},
    {x =365305.59375,   y =180480.87522888},
}
local p1 = cc.p(180837.00515747, 365008.6875)
local p2 = cc.p(557.78137207031, 184235.22900391)
local p3 = cc.p(184813.609375, 668.27575683594)
local p4 = cc.p(365305.59375, 180480.87522888)

return denemeMap
